
if (typeof gdjs.evtsExt__FlipGravity__FlipGravity1Object !== "undefined") {
  gdjs.evtsExt__FlipGravity__FlipGravity1Object.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__FlipGravity__FlipGravity1Object = {};
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachIndex4 = 0;

gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachObjects4 = [];

gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachTemporary4 = null;

gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachTotalCount4 = 0;

gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects5= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects1= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4= [];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects5= [];


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("FlipInAir"), false) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("FlipInAir"), false) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12981284);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))) - (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == -((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentFallSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12984564);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12986244);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects4Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList12 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("MoveAnimation")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList14 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3);

for (gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachIndex4 = 0;gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachIndex4 < gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3.length;++gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachIndex4) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4);
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4.length = 0;


gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachTemporary4 = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3[gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachIndex4];
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4.push(gdjs.evtsExt__FlipGravity__FlipGravity1Object.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects4Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentJumpSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[0].getPointY("")) >= (( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4[0].getY()) + (( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4[0].getHeight()));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12988460);
}
}
}
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(0);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed(0);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false);
}
}}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList13(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList15 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("JumpKey") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13005652);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("JumpStrength")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.asyncCallback13011764 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3);

{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setJumpSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalJumpSpeed"))));
}
}}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList16 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2) asyncObjectsList.addObject("Object", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.evtsExt__FlipGravity__FlipGravity1Object.asyncCallback13011764(runtimeScene, eventsFunctionContext, asyncObjectsList)));
}
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects1Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects1Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects1});
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList17 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalJumpSpeed")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getJumpSpeed()));
}
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13010916);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setJumpSpeed(100);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList16(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDObjectObjects1Objects, gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects1Objects, false, runtimeScene, false);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList18 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("TriggerOnce") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("TriggerOnce") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentJumpSpeed()) > (gdjs.RuntimeObject.getVariableNumber(((gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[0].getVariables()).get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(0);
}
}}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList10(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList11(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList14(runtimeScene, eventsFunctionContext);
}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentFallSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].isFlippedY()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12998324);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false);
}
}}

}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2[i].separateFromObjectsList(gdjs.evtsExt__FlipGravity__FlipGravity1Object.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity1Object_9546GDFloorObjects2Objects, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("JumpAbility") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList15(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList17(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList19 = function(runtimeScene, eventsFunctionContext) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity()));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getMaxFallingSpeed()));
}
}}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList18(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__FlipGravity__FlipGravity1Object.func = function(runtimeScene, Object, Behavior, Key, Floor, FlipForce, RightKey, LeftKey, IdleAnimation, MoveAnimation, FallAnimation, FlipInAir, TriggerOnce, JumpAbility, JumpKey, JumpStrength, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "Floor": Floor
},
  _objectArraysMap: {
"Object": gdjs.objectsListsToArray(Object)
, "Floor": gdjs.objectsListsToArray(Floor)
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "Key") return Key;
if (argName === "FlipForce") return FlipForce;
if (argName === "RightKey") return RightKey;
if (argName === "LeftKey") return LeftKey;
if (argName === "IdleAnimation") return IdleAnimation;
if (argName === "MoveAnimation") return MoveAnimation;
if (argName === "FallAnimation") return FallAnimation;
if (argName === "FlipInAir") return FlipInAir;
if (argName === "TriggerOnce") return TriggerOnce;
if (argName === "JumpAbility") return JumpAbility;
if (argName === "JumpKey") return JumpKey;
if (argName === "JumpStrength") return JumpStrength;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects1.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects2.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects3.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects4.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDObjectObjects5.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects1.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects2.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects3.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects4.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity1Object.GDFloorObjects5.length = 0;

gdjs.evtsExt__FlipGravity__FlipGravity1Object.eventsList19(runtimeScene, eventsFunctionContext);

return;
}

gdjs.evtsExt__FlipGravity__FlipGravity1Object.registeredGdjsCallbacks = [];