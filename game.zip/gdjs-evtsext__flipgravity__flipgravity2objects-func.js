
if (typeof gdjs.evtsExt__FlipGravity__FlipGravity2Objects !== "undefined") {
  gdjs.evtsExt__FlipGravity__FlipGravity2Objects.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__FlipGravity__FlipGravity2Objects = {};
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4 = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachObjects4 = [];

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTemporary4 = null;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTotalCount4 = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects5= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects5= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4= [];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects5= [];


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("FlipInAir"), false) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("FlipInAir"), false) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].flipY(true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{

/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].flipY(false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor()) ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_2 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0 ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_1 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].toggleVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true);
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("Key") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("FlippingTrigger"), false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("FlipInAir") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12869492);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))) - (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == -((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentFallSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12872716);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12874396);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects4Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects4Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList12 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("MoveAnimation")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList14 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3);

for (gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4 = 0;gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4 < gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3.length;++gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4.length = 0;


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTemporary4 = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3[gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects4Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentJumpSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[0].getAABBTop()) >= (( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4[0].getY()) + (( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4[0].getHeight()));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12876892);
}
}
}
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(0);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed(0);
}
}}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList13(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects4Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList15 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList16 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("RightKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("LeftKey") : ""));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("MoveAnimation")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList17 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3);

for (gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4 = 0;gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4 < gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3.length;++gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4);
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4.length = 0;


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTemporary4 = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3[gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachIndex4];
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects4Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentJumpSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[0].getPointY("")) >= (( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4[0].getY()) + (( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4[0].getHeight()));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12885700);
}
}
}
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(0);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("IdleAnimation")) || 0 : 0));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed(0);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false);
}
}}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList16(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects3Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList18 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2.length = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? "" + eventsFunctionContext.getArgument("JumpKey") : ""));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3[j]);
    }
}
}
{
gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12903868);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(-((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setCurrentFallSpeed((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("JumpStrength")) || 0 : 0));
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects3Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.asyncCallback12910828 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setJumpSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[i].getVariables().get("__FlipGravityExtension").getChild("OriginalJumpSpeed"))));
}
}}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList19 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2) asyncObjectsList.addObject("Object", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.evtsExt__FlipGravity__FlipGravity2Objects.asyncCallback12910828(runtimeScene, eventsFunctionContext, asyncObjectsList)));
}
}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects = Hashtable.newFrom({"Roof": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects = Hashtable.newFrom({"Object": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects = Hashtable.newFrom({"Floor": gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2});
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList20 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalJumpSpeed")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getJumpSpeed()));
}
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2.length = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3[j]);
    }
}
}
{
gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects3Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12910068);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setJumpSpeed(100);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).simulateJumpKey();
}
}
{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList19(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1);
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1.length = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].isFlippedY() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2[j]);
    }
}
}
{
gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDObjectObjects2Objects, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final.indexOf(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[j]) === -1 )
            gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final.push(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1);
gdjs.copyArray(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1_1final, gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("IsJumpingWhileFlipped"), false);
}
}}

}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList21 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("TriggerOnce") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("TriggerOnce") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipravityExtension").getChild("Flip"), true) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length === 0 ) ? 0 :gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[0].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentJumpSpeed()) > (gdjs.RuntimeObject.getVariableNumber(((gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[0].getVariables()).get("__FlipGravityExtension").getChild("MaxFallingSpeed"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity(0);
}
}}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList10(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList11(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList14(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList17(runtimeScene, eventsFunctionContext);
}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == (gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))) + (typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FlipForce")) || 0 : 0) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getCurrentFallSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].isFlippedY()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12895444);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setGravity((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity"))));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).setMaxFallingSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed"))), false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setVariableBoolean(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getVariables().get("__FlipGravityExtension").getChild("Flipping"), false);
}
}}

}


{



}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity() == 0) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[k] = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2 */
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].setAnimation((typeof eventsFunctionContext !== 'undefined' ? Number(eventsFunctionContext.getArgument("FallAnimation")) || 0 : 0));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Floor"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2);
gdjs.copyArray(eventsFunctionContext.getObjects("Roof"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].separateFromObjectsList(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDFloorObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2[i].separateFromObjectsList(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.mapOfGDgdjs_9546evtsExt_9595_9595FlipGravity_9595_9595FlipGravity2Objects_9546GDRoofObjects2Objects, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (typeof eventsFunctionContext !== 'undefined' ? !!eventsFunctionContext.getArgument("JumpAbility") : false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList18(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList20(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList22 = function(runtimeScene, eventsFunctionContext) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1);
{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("OriginalGravity")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getGravity()));
}
}{for(var i = 0, len = gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].returnVariable(gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getVariables().get("__FlipGravityExtension").getChild("MaxFallingSpeed")).setNumber((gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior")).getMaxFallingSpeed()));
}
}}

}


{


gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList21(runtimeScene, eventsFunctionContext);
}


};

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.func = function(runtimeScene, Object, Behavior, Key, Floor, Roof, FlipForce, RightKey, LeftKey, IdleAnimation, MoveAnimation, FallAnimation, FlipInAir, TriggerOnce, JumpAbility, JumpKey, JumpStrength, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "Floor": Floor
, "Roof": Roof
},
  _objectArraysMap: {
"Object": gdjs.objectsListsToArray(Object)
, "Floor": gdjs.objectsListsToArray(Floor)
, "Roof": gdjs.objectsListsToArray(Roof)
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "Key") return Key;
if (argName === "FlipForce") return FlipForce;
if (argName === "RightKey") return RightKey;
if (argName === "LeftKey") return LeftKey;
if (argName === "IdleAnimation") return IdleAnimation;
if (argName === "MoveAnimation") return MoveAnimation;
if (argName === "FallAnimation") return FallAnimation;
if (argName === "FlipInAir") return FlipInAir;
if (argName === "TriggerOnce") return TriggerOnce;
if (argName === "JumpAbility") return JumpAbility;
if (argName === "JumpKey") return JumpKey;
if (argName === "JumpStrength") return JumpStrength;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects1.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects2.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects3.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects4.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDObjectObjects5.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects1.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects2.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects3.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects4.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDFloorObjects5.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects1.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects2.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects3.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects4.length = 0;
gdjs.evtsExt__FlipGravity__FlipGravity2Objects.GDRoofObjects5.length = 0;

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.eventsList22(runtimeScene, eventsFunctionContext);

return;
}

gdjs.evtsExt__FlipGravity__FlipGravity2Objects.registeredGdjsCallbacks = [];